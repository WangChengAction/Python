
from distutils.core import setup

setup(
		name         = 'ListPrint',
		version      = '1.0.0',
		py_modules   = ['ListPrint'],
		author       = 'WangCheng',
		author_email = '378716031@q.com',
		url          = 'http://www.headfirstlabs.com',
		description  = 'A simple printer of nested lists', 

	)