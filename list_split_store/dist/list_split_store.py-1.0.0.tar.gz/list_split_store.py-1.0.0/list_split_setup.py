
from distutils.core import setup

setup(
		name 			= 'list_split_store.py',
		version		    = '1.0.0',
		py_modules		= ['list_split_store'],
		author   		= 'WangCheng',
		author_email	= '378716031@qq.com',
		url 			= 'git@github.com:WangChengAction/Python.git',
		description		= '针对一个小文件的分词，仅供自己学习使用 by.HeadFirst',

	)